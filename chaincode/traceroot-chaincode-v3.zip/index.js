"use strict";

const TraceRootContract = require("./lib/traceroot-contract");

module.exports.contracts = [TraceRootContract];
